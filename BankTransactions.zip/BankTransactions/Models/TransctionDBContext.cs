﻿using Microsoft.EntityFrameworkCore;

namespace BankTransactions.Models

{
    public class TransctionDBContext: DbContext
    {
        public TransctionDBContext(DbContextOptions<TransctionDBContext> options) : base(options)
        { }
            public DbSet<Transaction> Transactions { get; set;}
        
    }
}
