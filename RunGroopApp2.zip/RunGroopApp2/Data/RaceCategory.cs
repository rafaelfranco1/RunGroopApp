﻿namespace RunGroopApp2.Data
{
    public enum RaceCategory
    {
        Marathon,
        Ultra,
        Fivek,
        Tenk,
        HalfMarathon,
    }
}
