﻿namespace RunGroopApp2.Data
{
    public enum ClubCategory
    {
        RoadRunner,
        Womens,
        City,
        Trail,
        Endurance
    }
}
