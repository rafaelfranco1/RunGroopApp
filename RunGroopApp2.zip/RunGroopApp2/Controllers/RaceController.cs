﻿using Microsoft.AspNetCore.Mvc;

namespace RunGroopApp2.Controllers
{
    public class RaceController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
