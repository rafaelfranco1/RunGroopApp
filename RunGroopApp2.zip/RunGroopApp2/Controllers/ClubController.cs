﻿using Fluent.Infrastructure.FluentModel;
using Microsoft.AspNetCore.Mvc;

namespace RunGroopApp2.Controllers
{
    public class ClubController : Controller
    {
        public  ClubController(ApplicationDbContext contex)
        {

        }


        public IActionResult Index()
        {
            return View();
        }
    }
}
