﻿using System.Data.Entity;
using Microsoft.EntityFrameworkCore;
using RunGroopWebApp.Models;
using RunGroupWebApp.Models;

using DbContext = Microsoft.EntityFrameworkCore.DbContext;

namespace RunGroupWebApp.Data
{
   public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public Microsoft.EntityFrameworkCore.DbSet<Race> Races { get; set; }
        public System.Data.Entity.DbSet<Club> Clubs { get; set; }
        public System.Data.Entity.DbSet<Address> Addresses { get; set; }
    }
}

